---
title: Hero
---

#Welcome to PRIME
A Clean, Modern, Responsive Theme for GravCMS 
<br>
Built with the [**Primitive CSS Framework**](http://taniarascia.github.io/primitive/)

<a class="button accent-button"><i class="fa fa-download"></i>  Download PRIME</a>
<a class="button white-button">View on <i class="fa fa-github"></i> Github</a>