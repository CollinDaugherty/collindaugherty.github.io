---
title: Home
content:
  items: '@self.modular'
  order:
    custom:
      - _hero
      - _features
      - _services
      - _blogfeed
      - _testmonials
---