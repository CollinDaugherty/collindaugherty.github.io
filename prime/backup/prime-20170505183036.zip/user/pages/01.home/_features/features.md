---
title: Features
---

[fa=diamond extras=fa-5x /]
## Clean

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur nobis in nemo. Quibusdam reprehenderit quos.

---

[fa=star extras=fa-5x /]
## Modern

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis voluptates assumenda eveniet ad praesentium, est!

---

[fa=mobile extras=fa-5x /]
## Responsive

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni amet ea nobis, laboriosam aliquid reprehenderit.
