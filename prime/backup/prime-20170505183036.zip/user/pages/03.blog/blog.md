---
content:
    items: '@self.children'
    limit: 10
    pagination: true
---